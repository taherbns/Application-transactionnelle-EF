﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExamenFinal.Models
{
    public class Offre
    {
        public int Id { get; set; }
        public string titre { get; set; }
        public string description { get; set; }
        public int salaire { get; set; }
    }
}