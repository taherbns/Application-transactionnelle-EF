﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExamenFinal.Models
{
    public class Candidat
    {
        public int Id { get; set; }
        public string nom { get; set; }
        public string prenom { get; set; }
        public string description { get; set; }
        public int salaire { get; set; }
    }
}