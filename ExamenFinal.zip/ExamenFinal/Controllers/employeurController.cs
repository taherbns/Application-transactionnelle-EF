﻿using ExamenFinal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ExamenFinal.Controllers
{
    public class employeurController : Controller
    {
        private examenEntities data;
        // GET: employeur
        public ActionResult CreateCandidat(candidat Candidat)
        {
            this.data = new examenEntities();
            candidat c = new candidat
            {
                Id = Candidat.Id,
                nom = Candidat.nom,
                prenom = Candidat.prenom,
                description = Candidat.description,
                salaire = Candidat.salaire
            };
            data.candidat.Add(c);
            data.SaveChanges();
            return View();
            
        }
        public ActionResult getCandidats(candidat candidat)
        {
            this.data = new examenEntities();
            List<Candidat> lst = data.candidat
             .Select(n => new Candidat
             {
                 Id = n.Id,
                 nom = n.nom,
                 prenom = n.prenom,
                 description = n.description,
                 salaire = n.salaire


             }) 
             .ToList();
            return View(lst);
        }

        public ActionResult UpdateCandidats()
        {
            this.data = new examenEntities();
            try
            {
                List<Candidat> lstOF = data.candidat
                    .Select(n => new Candidat
                    {
                        salaire = n.salaire

                    }).ToList();


            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = ex.Message;
            }
            return View();
        }
        [HttpPost]
        public ActionResult UpdateCandidats(Candidat can, int Id)
        {
            this.data = new examenEntities();
            try
            {

                candidat existingCandidat = data.candidat.SingleOrDefault(p => p.Id == Id);
                if (existingCandidat != null)
                {
                    existingCandidat.salaire = can.salaire;


                    data.SaveChanges();
                }

            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = ex.Message;
            }
            return View();
        }

        public ActionResult DeleteCandidats()
        {
            this.data = new examenEntities();
            List<Candidat> lst = data.candidat
                   .Select(n => new Candidat
                   {
                       Id = n.Id,
                       nom = n.nom,
                       prenom = n.prenom
                   }).ToList();

            ViewBag.OffreId = new SelectList(lst, "Id", "nom" , "prenom");
            return View();
        }
        [HttpPost]
        public ActionResult DeleteCandidats(int Id)
        {
            this.data = new examenEntities();
            var entiteASupprimer = data.offre.Find(Id);

            if (entiteASupprimer != null)
            {
                data.offre.Remove(entiteASupprimer);
                data.SaveChanges();
            }
            else
            {
                ViewBag.ErrorMessage = "L'entité à supprimer n'a pas été trouvée.";
            }
            return View();
        }
    }
}