﻿using ExamenFinal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ExamenFinal.Controllers
{
    
    public class candidatController : Controller
    {
        private examenEntities data; 
        // GET: candidat
        public ActionResult AddOffre(offre Offre)
        {
            this.data = new examenEntities();
            offre o = new offre
            { Id=Offre.Id,
                titre = Offre.titre,
                description = Offre.description,
                salaire = Offre.salaire
            };
            data.offre.Add(o);
            data.SaveChanges();
            return View();
        }
        public ActionResult getOffres(offre Offre)
        {
            this.data = new examenEntities();
            List<Offre> lst = data.offre
             .Select(n => new Offre
             {
                 Id = n.Id,
                 titre = n.titre,
                 description = n.description,
                 salaire = n.salaire

             })
             .ToList();
            return View(lst);
        }

        public ActionResult UpdateOffre()
        {
            this.data = new examenEntities();
            try
            {
                List<Offre> lstOF = data.offre
                    .Select(n => new Offre
                    {
                       salaire=n.salaire
                       
                    }).ToList();

                
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = ex.Message;
            }
            return View();
        }
        [HttpPost]
        public ActionResult UpdateOffre(Offre off, int Id)
        {
            this.data = new examenEntities();
            try
            {

                offre existingOffre = data.offre.SingleOrDefault(o => o.Id == Id);
                if (existingOffre != null)
                {
                    existingOffre.salaire = off.salaire;


                    data.SaveChanges();
                }

            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = ex.Message;
            }
            return View();
        }

        public ActionResult DeleteOffre()
        {
            this.data = new examenEntities();
            List<Offre> lst = data.offre
                   .Select(n => new Offre
                   {
                       Id = n.Id,
                       titre = n.titre
                   }).ToList();

            ViewBag.OffreId = new SelectList(lst, "Id", "titre");
            return View();
        }
        [HttpPost]
        public ActionResult DeleteOffre(int Id)
        {
            this.data = new examenEntities();
            var entiteASupprimer = data.offre.Find(Id);

            if (entiteASupprimer != null)
            {
                data.offre.Remove(entiteASupprimer);
                data.SaveChanges();
            }
            else
            {
                ViewBag.ErrorMessage = "L'entité à supprimer n'a pas été trouvée.";
            }
            return View();
        }
    }
}